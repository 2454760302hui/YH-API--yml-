#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
项目环境设置脚本
"""

import os
import sys
import subprocess
from pathlib import Path

def install_dependencies():
    """安装项目依赖"""
    print("📦 安装项目依赖...")

    requirements_file = Path(__file__).parent.parent / "requirements.txt"

    if requirements_file.exists():
        try:
            subprocess.check_call([
                sys.executable, "-m", "pip", "install",
                "-r", str(requirements_file)
            ])
            print("✅ 依赖安装成功")
        except subprocess.CalledProcessError as e:
            print(f"❌ 依赖安装失败: {e}")
            return False
    else:
        print("⚠️ requirements.txt 文件不存在")
        return False

    return True

def setup_directories():
    """创建必要的目录"""
    print("📁 创建项目目录...")

    project_root = Path(__file__).parent.parent
    directories = [
        "reports/allure-results",
        "reports/html",
        "logs",
        "data/mock_responses"
    ]

    for directory in directories:
        dir_path = project_root / directory
        dir_path.mkdir(parents=True, exist_ok=True)
        print(f"✅ 创建目录: {directory}")

def check_python_version():
    """检查Python版本"""
    print("🐍 检查Python版本...")

    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python版本过低，需要Python 3.8+")
        return False

    print(f"✅ Python版本: {version.major}.{version.minor}.{version.micro}")
    return True

def main():
    """主函数"""
    print("🚀 YH API测试框架 - 环境设置")
    print("=" * 40)

    # 检查Python版本
    if not check_python_version():
        sys.exit(1)

    # 创建目录
    setup_directories()

    # 安装依赖
    if not install_dependencies():
        sys.exit(1)

    print("\n🎉 环境设置完成!")
    print("💡 现在可以运行 'python run.py' 开始测试")

if __name__ == "__main__":
    main()
