#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
项目清理脚本
"""

import os
import shutil
from pathlib import Path

def clean_reports():
    """清理测试报告"""
    print("🧹 清理测试报告...")

    project_root = Path(__file__).parent.parent
    report_dirs = [
        "reports/allure-results",
        "reports/html"
    ]

    for report_dir in report_dirs:
        dir_path = project_root / report_dir
        if dir_path.exists():
            shutil.rmtree(dir_path)
            dir_path.mkdir(parents=True, exist_ok=True)
            print(f"✅ 清理目录: {report_dir}")

def clean_logs():
    """清理日志文件"""
    print("📝 清理日志文件...")

    project_root = Path(__file__).parent.parent
    logs_dir = project_root / "logs"

    if logs_dir.exists():
        for log_file in logs_dir.glob("*.log"):
            log_file.unlink()
            print(f"✅ 删除日志: {log_file.name}")

def clean_cache():
    """清理缓存文件"""
    print("🗑️ 清理缓存文件...")

    project_root = Path(__file__).parent.parent

    # 清理Python缓存
    for cache_dir in project_root.rglob("__pycache__"):
        shutil.rmtree(cache_dir)
        print(f"✅ 删除缓存: {cache_dir}")

    # 清理.pyc文件
    for pyc_file in project_root.rglob("*.pyc"):
        pyc_file.unlink()
        print(f"✅ 删除文件: {pyc_file}")

def main():
    """主函数"""
    print("🧹 YH API测试框架 - 项目清理")
    print("=" * 40)

    clean_reports()
    clean_logs()
    clean_cache()

    print("\n🎉 项目清理完成!")

if __name__ == "__main__":
    main()
