# YH API测试框架项目

## 📖 项目简介

这是一个基于YH API测试框架的完整测试项目，提供了全面的API测试解决方案。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境

修改 `config/config.yaml` 文件，设置您的API基础地址和认证信息：

```yaml
api:
  base_url: "https://your-api.example.com"
  timeout: 30

auth:
  type: "bearer"
  token: "your_token_here"
```

### 3. 运行测试

```bash
python run.py
```

### 4. 查看报告

测试完成后，报告将生成在 `reports/` 目录下。

## 📁 项目结构

```
yh-api-test-project/
├── README.md                 # 项目说明文档
├── requirements.txt          # 依赖包列表
├── run.py                   # 主运行脚本
├── config/                  # 配置文件目录
│   ├── config.yaml         # 主配置文件
│   ├── environments.yaml   # 环境配置
│   └── global_vars.yaml    # 全局变量
├── test_cases/             # 测试用例目录
│   ├── api_tests/          # API测试用例
│   └── performance_tests/  # 性能测试用例
├── reports/                # 测试报告目录
├── logs/                   # 日志目录
├── data/                   # 测试数据目录
└── scripts/                # 辅助脚本
```

## 🧪 测试用例说明

### API测试用例
- `login_test.yaml`: 用户登录接口测试
- `user_test.yaml`: 用户管理接口测试
- `product_test.yaml`: 产品管理接口测试

### 性能测试用例
- `load_test.yaml`: 负载测试用例

## ⚙️ 配置说明

### 主配置文件 (config/config.yaml)
包含API基础地址、认证信息、超时设置等。

### 环境配置 (config/environments.yaml)
支持多环境配置，如开发、测试、生产环境。

### 全局变量 (config/global_vars.yaml)
定义全局变量，可在测试用例中引用。

## 📊 报告功能

项目集成了Allure报告，提供：
- 详细的测试结果展示
- 测试步骤和断言信息
- 请求响应数据
- 测试趋势分析
- 失败用例截图和日志

## 🔧 自定义开发

### 添加新的测试用例
1. 在 `test_cases/` 目录下创建新的YAML文件
2. 按照框架规范编写测试用例
3. 运行 `python run.py` 执行测试

### 修改配置
根据实际API接口修改配置文件中的地址、认证等信息。

## 📞 技术支持

如果您在使用过程中遇到问题，欢迎联系：
- **QQ**: 2677989813

## 📝 更新日志

### v1.0.0
- 初始版本发布
- 包含基础API测试功能
- 集成Allure报告
- 支持多环境配置
